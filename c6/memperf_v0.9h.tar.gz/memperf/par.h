extern int par_cid;
extern int par_npes;
extern int par_semid;

extern int barrier();
extern int sem_init();
extern int sem_deinit();
extern int begin_parallel(int n); 
extern int end_parallel();


