#define MINN 50
#define MAXN 700
#define INCN 50

typedef double array[MAXN][MAXN+513];

#define min(x,y) (x<y?x:y)

